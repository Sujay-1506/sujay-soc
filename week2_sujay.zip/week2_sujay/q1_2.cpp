#include<iostream>
using namespace std;
#include<vector>
 
int main(){

   int n,x;
    cin >> n;
   vector<int> testcases(n);
   vector< vector<int> > a(n);

   for(int i=0;i<n;i++){
      cin >> testcases[i];

      a[i]= vector<int>(testcases[i]);

      for(int j=0;j<testcases[i];j++){
        cin >> a[i][j];
      }
   }
    
    for(int i=0;i<n;i++){

        if(testcases[i]%2==1){
            cout << "YES" << endl;
        }
        else{
       for (int j=0;j<testcases[i]-2;j++){
               x=a[i][j+1]-a[i][j];
               a[i][j+1]=a[i][j+1]-x;
               a[i][j+2]=a[i][j+2]-x;
                
            }

                if(a[i][testcases[i]-1] >= a[i][testcases[i]-2] ){

                cout << "YES" << endl;
            }

            else{
                cout << "NO" << endl;
            }

        }
    }




   


} 
