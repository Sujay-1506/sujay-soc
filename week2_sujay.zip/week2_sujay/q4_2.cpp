#include<iostream>
using namespace std;
#include<vector>
#include<cstdlib>
#include<algorithm>
 
int main(){

   int n,l=0;
    cin >> n;
   vector<int> testcases(n);
   vector< vector<int> > a(n);

   for(int i=0;i<n;i++){
      cin >> testcases[i];

      a[i]= vector<int>(2*testcases[i]);

      for(int j=0;j<2*testcases[i];j++){
        cin >> a[i][j];
      }
   }
   
   for(int i=0;i<n;i++){

    sort(a[i].begin(),a[i].end());

    for(int j=0;j<testcases[i]-1;j++){
        l+=abs(a[i][j]-a[i][j+1]);
        l+=abs(a[i][j+testcases[i]]-a[i][j+testcases[i]+1]);

    }

    cout << l << endl;
    l=0;

    for(int j=0;j<testcases[i];j++){

        cout << a[i][j] << " " << a[i][j+testcases[i]] << endl;
        
    }







   }
   
   
   
   }