#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    long long int n, D, x;
    
    cin >> n >> D;
    vector<long long int> P(n);
    
    for (long long int i = 0; i < n; ++i) {
        cin >> P[i];
    }

    sort(P.begin(), P.end());
    
    int left = 0;
    int right = n - 1;
    vector<long long int> v;

    while (left <= right) {
        x = (D / P[right]) + 1;

        if (right - left + 1 >= x) {
            v.push_back(x);
            right--;  
            left += x - 1; 
        } else {
            break;  
        }
    }

    cout << v.size() << endl;

    return 0;
}