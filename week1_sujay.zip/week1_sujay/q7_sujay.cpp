#include <iostream>

using namespace std;

int* binary(int n) {
    int* binary = new int[32];
    fill(binary, binary + 32, 0); 

    int i = 0;
    while (n > 0) {
        binary[i] = n % 2;
        n = n / 2;
        i++;
    }

    return binary;
}

int main() {
	int n;
	cin >> n;
	int* a ;
	a = binary(n);
	for(int x=0; x<n; x++) {
		int* b = binary(x);
		int* c = binary(n+x);
		int XOR[32];
		for(int i=0; i<32; i++) {
			if(b[i]==a[i]) XOR[i] = 0 ;
			if(b[i] != a[i]) XOR[i] = 1 ;
		} 
		bool d = true;
		for(int i=0; i<32; i++) {
			if(c[i] != XOR[i]) d=false;
		}
		if(d) cout << x << " " ;
	delete [] b;
	delete [] c;

}
delete [] a;
}
	