#include<bits/stdc++.h>
using namespace std;

int main(){
    int testcases;
    cin>>testcases;

    for(int i=0;i<testcases;i++){
        string s;
        cin>>s;
        vector<char> check;
        for(int j=0;j<s.size();j++){
            if(s[j]=='(' || s[j]=='{' || s[j]=='['){
                check.push_back(s[j]);
            }
            else{
                if (check.size()==0){
                    cout<<"false"<<endl;
                    return 0;
                }
                else if ((s[j]==')' && check.back()=='(') || (s[j]=='}' && check.back()=='{') || (s[j]==']' && check.back()=='[')){
                    check.pop_back();
                }
                else{
                    cout<<"false"<<endl;
                    return 0;
                }
            }
        }
        if (check.size()==0){
            cout<<"true"<<endl;
            return 0;
        }
        else{
            cout<<"false"<<endl;
            return 0;
        }

    }
}