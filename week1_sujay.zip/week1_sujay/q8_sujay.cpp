#include<bits/stdc++.h>
using namespace std;

int output(int n,int target, vector<int> array){
    int a,b;
    int val;
    int count=0;
    for(a=0;a<n-1;a++){
        for(b=a+1;b<n;b++){
            val=array[a]^array[a+1];
            if (b>=a+2){
                for(int i=a+2;i<=b;i++){
                    val=val^array[i];
                }
            }
            if (val==target){
                count++;
            }
        }
    }
    for(int i=0;i<n;i++){
        if (array[i]==target){
            count++;
        }
    }
    return count;
}

int main(){
    int testcases;
    cin>>testcases;
    for(int j=0;j<testcases;j++){    
        int n,target;
        cin>>n>>target;
        vector<int> array(n);
        for(int i=0;i<n;i++){
            cin>>array[i];
        }
        cout<<output(n,target,array)<<endl;
    }

}