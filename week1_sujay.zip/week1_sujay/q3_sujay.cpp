#include<simplecpp>
main_program{
    int n,target;
    cin >> n >> target;
     int numbers[n+1];
        for(int i=1;i<=n;i++){
                cin >> numbers[i];
        }


        int i=1,j=2;
        int ind1,ind2;

        while(i<n){

            while(j<=n){

                if(numbers[i]+numbers[j]==target){

                    ind1=i;
                    ind2=j;
                    break;

                }
                j=j+1;


            }
            
            i=i+1;
            j=i+1;
        }


        cout << ind1 << " " << ind2;




}