#include<simplecpp>
main_program{
        int n;
        cin >> n  ;
        int nums[n];
        for(int i=0;i<n;i++){
                cin >> nums[i];
        }

        int i=1,x=0,j=0,sum=0,k=nums[0],output=0;
        while(i<=n){

             while(j+i<=n){

                x=j;

                while(x<i+j){
                    sum += nums[x];
                    x=x+1;
                }                  



              if(sum>=k) {

                output=sum;

                k=output;
              } 
               
               

                

               sum=0;
                j=j+1;

             }

             j=0;

             i=i+1;

        }

      


        cout<< output;
        
        
        
        
        
        
        
        
        
        
        
        
        }