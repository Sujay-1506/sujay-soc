#include<simplecpp>
main_program{
    int n;
    cin >>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin >> arr[i];
    } 

    int i=0,output=0;
    while(i<n-1){
        if(arr[i]>arr[i+1]){

            output=i+1;

            break;

        }
        i=i+1;
    }


    cout << arr[output];


}