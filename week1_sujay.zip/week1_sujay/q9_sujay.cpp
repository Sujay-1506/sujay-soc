#include<simplecpp>
main_program{
    int k;
    cin >> k;
    string s;
    cin >> s;

    cout << s.length()-k+1;



}