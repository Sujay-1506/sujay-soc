#include<simplecpp>
main_program{
        int n,k;
        cin >> n >> k ;
        int arr[n];
        for(int i=0;i<n;i++){
                cin >> arr[i];
        }

       int i=0,sub[k],max;

       while(i+k<=n){

          for(int j=0;j<k;j++){
             sub[j]=arr[i+j];

          }

          max=sub[0];

          for( int j=0;j<k;j++){

            if(sub[j]>max){
                max=sub[j];
            }


          }

          cout << max << " " ;
    

                  i=i+1;  
        
       }



}
